import boto3
import json
import random
from boto3.dynamodb.conditions import Key
import requests
from requests_aws4auth import AWS4Auth


credentials = boto3.Session().get_credentials()
authent = AWS4Auth(credentials.access_key, credentials.secret_key, 'us-east-1', 'es', session_token=credentials.token)
print(authent, "auth")


#connect to the dynamoDB
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('yelp-restaurants')

# yelp API details to query later
API_KEY = 'm68Jb9xYu4eUQH0RKbjlFGOj6lzCEEdExprjLAj3Bw8inSDYbODwF1EO13wr1QXaz68XUeoB-Ay-yxwaC4y1KqqHOWc6towlxTvyAXKooWHtYAepY4okWAbeP1SlXHYx'
API_HOST = 'https://api.yelp.com'
SEARCH_PATH = '/v3/businesses/search'
BUSINESS_PATH = '/v3/businesses/'  # Business ID will come after slash.
DEFAULT_TERM = 'dinner'
DEFAULT_LOCATION = 'Manhattan'
SEARCH_LIMIT = 1

#function to handle the lambda function
def lambda_handler(event, context):
    handle_queue_item()

# function to handle the response
def format_response(response):
    # if 'price' in dbRes['Items'][0].keys():
    #         price = str(dbRes['Items'][0]['price'])
    # else:
    #     price = 'NA'
    # if 'phone' in dbRes['Items'][0].keys():
    #     restaurant_phone = str(dbRes['Items'][0]['phone'])
    # else:
    #     restaurant_phone = 'NA'
    # addr = str(dbRes['Items'][0]['address'])
    # for char in "'u[]":
    #     addr = addr.replace(char, '')
    # message = 'This is an ideal(random) deal for you:\n' + 'Restaurant Name: ' + dbRes['Items'][0][
    #     'name'] + '\n' + 'Price: ' + price + '\n' + 'Phone: ' + restaurant_phone + '\n' + 'Address: ' + addr
    return response


# function to send an email
def send_plain_email(fromEmailAddress, toEmailAddress, message):
    ses_client = boto3.client("ses", region_name="us-east-1")
    CHARSET = "UTF-8"

    response = ses_client.send_email(
        Destination={
            "ToAddresses": toEmailAddress,
        },
        Message={
            "Body": {
                "Text": {
                    "Charset": CHARSET,
                    "Data": message,
                }
            },
            "Subject": {
                "Charset": CHARSET,
                "Data": "Your restaurant recommendations",
            },
        },
        Source=fromEmailAddress,
    )
    print(response)

def handle_queue_item():
    # create a boto3 client connect to the queue
    client = boto3.client('sqs')

    # get a list of queues, we get back a dict with 'QueueUrls' as a key with a list of queue URLs
    queues = client.list_queues(QueueNamePrefix='restaurantRequests')
    queue_url = queues['QueueUrls'][0]

    # get the response from the queue
    response = client.receive_message(
        QueueUrl=queue_url,
        AttributeNames=[
            'All'
        ],
        MaxNumberOfMessages=10,
        MessageAttributeNames=[
            'All'
        ],
        VisibilityTimeout=30,
        WaitTimeSeconds=0
    )
    
    print(response, "queue response")

    # if there are messages in the queue
    if len(response['Messages']) > 0:
        for message in response['Messages']:  # 'Messages' is a list
            js = json.loads(message['Body'])
            cuisine = js['cuisine']
            email = js['email']

            # call the elastic search
            url = 'https://search-restaurant-2xxoafusnhkyn4gmypsml2uzd4.us-east-1.es.amazonaws.com/restaurant/restaurants/_search?from=0&&size=1&&q=Cuisine:' + cuisine
            elastic_response = requests.get(url, auth = authent, headers={"Content-Type": "application/json"}).json()
            print(elastic_response, "elastic response")
            number_of_hits = elastic_response['hits']["total"]
            
            # get a random restaurant
            random_restaurant_index = random.randint(0, number_of_hits - 1)

            # get elastic search results for the random restaurant
            url2 = 'https://search-restaurant-2xxoafusnhkyn4gmypsml2uzd4.us-east-1.es.amazonaws.com/restaurant/restaurants/_search?from=' + str(random_restaurant_index) + '&&size=1&&q=Cuisine:' + cuisine
            random_elastic_response = requests.get(url2, headers={"Content-Type": "application/json"}).json()
            restaurant_ID = random_elastic_response['hits']['hits'][0]['_source']['RestaurantID']

            # use the elastic ID to get full details from dynamoDb
            dynamoDBResponse = table.query(KeyConditionExpression=Key('insertedAtTimestamp').eq(restaurant_ID))
            output = format_response(dynamoDBResponse)
            print(output)

            # send the message
            send_plain_email('hsgrandhi@gmail.com', str(email), str(output))

            # delete the message from the queue
            client.delete_message(QueueUrl=queue_url, ReceiptHandle=message['ReceiptHandle'])

    else:
        print('Queue is empty')

